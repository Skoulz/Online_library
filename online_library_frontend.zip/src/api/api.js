import axios from 'axios';

const API_URL = 'http://localhost:3000';

export const loginUser = (credentials) => {
    return axios.post(`${API_URL}/login`, credentials);
};

export const getBooks = (filters) => {
    const params = new URLSearchParams(filters).toString();
    return axios.get(`${API_URL}/books/search?${params}`);
};