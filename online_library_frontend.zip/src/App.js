import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import BookList from './components/BookList';

const App = () => {
    const [token, setToken] = useState(null);

    return (
        <Router>
            <Routes>
                <Route path="/" element={<BookList />} />
                <Route path="/login" element={<LoginForm setToken={setToken} />} />
            </Routes>
        </Router>
    );
};

export default App;