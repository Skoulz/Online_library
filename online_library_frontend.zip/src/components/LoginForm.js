import React, { useState } from 'react';
import { loginUser } from '../api/api';

const LoginForm = ({ setToken }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const { data } = await loginUser({ email, password });
            setToken(data.token);
            alert('Pieslēgšanās veiksmīga!');
        } catch (err) {
            setError('Nepareizs e-pasts vai parole.');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Pieslēgšanās</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <div>
                <label>E-pasts</label>
                <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
            </div>
            <div>
                <label>Parole</label>
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
            </div>
            <button type="submit">Pieslēgties</button>
        </form>
    );
};

export default LoginForm;