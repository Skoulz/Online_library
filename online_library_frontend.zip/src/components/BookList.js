import React, { useState, useEffect } from 'react';
import { getBooks } from '../api/api';

const BookList = () => {
    const [books, setBooks] = useState([]);
    const [filters, setFilters] = useState({});

    useEffect(() => {
        const fetchBooks = async () => {
            try {
                const { data } = await getBooks(filters);
                setBooks(data);
            } catch (error) {
                alert('Kļūda, iegūstot grāmatas');
            }
        };
        fetchBooks();
    }, [filters]);

    return (
        <div>
            <h2>Pieejamās grāmatas</h2>
            <ul>
                {books.map((book) => (
                    <li key={book.book_id}>
                        <strong>{book.title}</strong> - {book.price} €
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default BookList;